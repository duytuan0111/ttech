@extends('frontend.layouts.default')

@section('content')

@endsection
